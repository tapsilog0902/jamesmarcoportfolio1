# Attractive Advance Portfolio Website
## _Chatting Bot Like Design (Whatsapp like interface)_


- [Running Site](https://vinayak-09.github.io/)

[![N|Solid](images/demo.gif)](https://vinayak-09.github.io/)

## Technologies Used

- HTML
- Javascript
- CSS

## Features

- Whatsapp like interface
- Pleasant sounds
- Lightweighted
- Social media links
- Download resume.
- Map support for address
- Random replies for hi, bye, i love you.

<br><br>

## Connect with Me: 

<br>

[![N|Solid](images/telegram.svg)](https://t.me/vinayak_09)


[![N|Solid](images/instagram.svg)](https://instagram.com/vinayak_patil_09)


<br>

**Free Software, Hell Yeah!**
